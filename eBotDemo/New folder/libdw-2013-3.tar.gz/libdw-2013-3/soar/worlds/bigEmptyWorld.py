initialRobotLoc(1.0, 1.0)
dimensions(4.05,4.05)
